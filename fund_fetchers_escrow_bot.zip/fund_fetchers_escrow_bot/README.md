
# Fund Fetchers Escrow Bot

A starter Telegram escrow ecosystem built with Python and aiogram.

## Includes
- Escrow bot
- Reputation/vouch bot
- SQLite database
- Deal creation flow
- Dispute alerts
- Reputation tracking
- Marketplace structure examples

## Setup

1. Install Python 3.11+
2. Install requirements:

```bash
pip install -r requirements.txt
```

3. Create bots using BotFather on Telegram.

4. Add your bot tokens to `.env`

Example:

```env
ESCROW_BOT_TOKEN=YOUR_TOKEN
REP_BOT_TOKEN=YOUR_TOKEN
ADMIN_ID=123456789
```

5. Run:

```bash
python escrow_bot.py
```

## Features

### Escrow Bot
- /start
- /newdeal
- /confirm
- /dispute
- automatic status tracking

### Reputation Bot
- /rep
- /vouch
- successful deal counter

## Recommended Hosting
- Railway
- Render
- DigitalOcean
