
import aiosqlite

DB_NAME = "escrow.db"

async def setup_db():
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute('''
            CREATE TABLE IF NOT EXISTS deals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                buyer TEXT,
                seller TEXT,
                amount TEXT,
                status TEXT
            )
        ''')

        await db.execute('''
            CREATE TABLE IF NOT EXISTS reputation (
                username TEXT PRIMARY KEY,
                successful_deals INTEGER DEFAULT 0
            )
        ''')

        await db.commit()
