
import asyncio
import os
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from dotenv import load_dotenv
from database import setup_db
import aiosqlite

load_dotenv()

TOKEN = os.getenv("ESCROW_BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

bot = Bot(token=TOKEN)
dp = Dispatcher()

@dp.message(Command("start"))
async def start(message: types.Message):
    await message.answer(
        "Welcome to Fund Fetchers Escrow. Use /newdeal buyer seller amount"
    )

@dp.message(Command("newdeal"))
async def newdeal(message: types.Message):
    try:
        parts = message.text.split()
        buyer = parts[1]
        seller = parts[2]
        amount = parts[3]

        async with aiosqlite.connect("escrow.db") as db:
            await db.execute(
                "INSERT INTO deals (buyer, seller, amount, status) VALUES (?, ?, ?, ?)",
                (buyer, seller, amount, "PENDING")
            )
            await db.commit()

        await message.answer(
            f"Deal created between {buyer} and {seller} for {amount}."
        )

    except:
        await message.answer(
            "Usage: /newdeal @buyer @seller amount"
        )

@dp.message(Command("confirm"))
async def confirm(message: types.Message):
    await message.answer("Deal marked as completed.")

@dp.message(Command("dispute"))
async def dispute(message: types.Message):
    await bot.send_message(
        ADMIN_ID,
        f"DISPUTE ALERT from @{message.from_user.username}"
    )

    await message.answer(
        "Dispute submitted. Admin has been notified."
    )

async def main():
    await setup_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
