
import asyncio
import os
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from dotenv import load_dotenv
import aiosqlite

load_dotenv()

TOKEN = os.getenv("REP_BOT_TOKEN")

bot = Bot(token=TOKEN)
dp = Dispatcher()

@dp.message(Command("start"))
async def start(message: types.Message):
    await message.answer("Fund Fetchers Reputation Bot")

@dp.message(Command("rep"))
async def rep(message: types.Message):
    try:
        username = message.text.split()[1]

        async with aiosqlite.connect("escrow.db") as db:
            cursor = await db.execute(
                "SELECT successful_deals FROM reputation WHERE username=?",
                (username,)
            )

            result = await cursor.fetchone()

        if result:
            await message.answer(
                f"{username} has {result[0]} successful deals."
            )
        else:
            await message.answer(
                f"No reputation found for {username}."
            )

    except:
        await message.answer(
            "Usage: /rep @username"
        )

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
